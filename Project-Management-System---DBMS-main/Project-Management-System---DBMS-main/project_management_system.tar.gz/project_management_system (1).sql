-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2024 at 04:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `C_ID` int(11) NOT NULL,
  `C_NAME` varchar(50) DEFAULT NULL,
  `C_MAIL` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`C_ID`, `C_NAME`, `C_MAIL`) VALUES
(1, 'Molla Rashied Hussein', 'rashied@gmail.com'),
(2, 'Shammi Akhtar', 'shamm@gmail.com'),
(3, 'Md. Shahidul Islam', 'shahid@gmail.com'),
(4, 'Tahera Parvin', 'tahera@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `meeting`
--

CREATE TABLE `meeting` (
  `M_ID` int(11) NOT NULL,
  `M_TITLE` varchar(50) DEFAULT NULL,
  `M_DATE_TIME` date DEFAULT NULL,
  `T_ID` int(11) DEFAULT NULL,
  `TEAM_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meeting`
--

INSERT INTO `meeting` (`M_ID`, `M_TITLE`, `M_DATE_TIME`, `T_ID`, `TEAM_ID`) VALUES
(1, 'Start', '2024-01-05', 1, 1),
(2, 'Review', '2024-02-05', 2, 2),
(3, 'Update', '2024-03-05', 3, 3),
(4, 'Planning', '2024-04-05', 4, 1),
(5, 'Explain', '2024-05-05', 5, 2),
(6, 'Mid Way Met', '2024-06-05', 6, 3),
(7, 'Brainstorming', '2024-07-05', 7, 1),
(8, 'Report', '2024-08-05', 8, 2),
(9, 'Demo', '2024-09-05', 9, 3),
(10, 'Post Project Discussion', '2024-10-05', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `P_ID` int(11) NOT NULL,
  `P_NAME` varchar(50) DEFAULT NULL,
  `START_DATE` date DEFAULT NULL,
  `END_DATE` date DEFAULT NULL,
  `TEAM_ID` int(11) DEFAULT NULL,
  `C_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`P_ID`, `P_NAME`, `START_DATE`, `END_DATE`, `TEAM_ID`, `C_ID`) VALUES
(1, 'UAP', '2024-01-01', '2024-02-01', 1, 1),
(2, 'DBMS Project', '2024-02-01', '2024-03-01', 2, 2),
(3, 'Java Project', '2024-03-01', '2024-04-01', 3, 3),
(4, 'Front End', '2024-04-01', '2024-05-01', 1, 4),
(5, 'Back End', '2024-05-01', '2024-06-01', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reminder`
--

CREATE TABLE `reminder` (
  `R_ID` int(11) NOT NULL,
  `R_TITLE` varchar(50) DEFAULT NULL,
  `R_DATE_TIME` date DEFAULT NULL,
  `R_TYPE` varchar(50) DEFAULT NULL,
  `M_ID` int(11) DEFAULT NULL,
  `T_ID` int(11) DEFAULT NULL,
  `U_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reminder`
--

INSERT INTO `reminder` (`R_ID`, `R_TITLE`, `R_DATE_TIME`, `R_TYPE`, `M_ID`, `T_ID`, `U_ID`) VALUES
(1, 'Task 1', '2024-01-10', 'Email', 1, 1, 1),
(2, 'Task 2', '2024-02-10', 'Notification', 2, 2, 2),
(3, 'Task 3', '2024-03-10', 'SMS', 3, 3, 3),
(4, 'Task 4', '2024-04-10', 'Email', 4, 4, 4),
(5, 'Task 5', '2024-05-10', 'Notification', 5, 5, 5),
(6, 'Task 6', '2024-06-10', 'SMS', 6, 6, 6),
(7, 'Task 7', '2024-07-10', 'Email', 7, 7, 7),
(8, 'Task 8', '2024-08-10', 'Notification', 8, 8, 8),
(9, 'Task 9', '2024-09-10', 'SMS', 9, 9, 9),
(10, 'Task 10', '2024-10-10', 'Email', 10, 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `REPORT_ID` int(11) NOT NULL,
  `DATE` date DEFAULT NULL,
  `P_ID` int(11) DEFAULT NULL,
  `TEAM_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`REPORT_ID`, `DATE`, `P_ID`, `TEAM_ID`) VALUES
(1, '2024-01-31', 1, 1),
(2, '2024-02-28', 2, 2),
(3, '2024-03-31', 3, 3),
(4, '2024-04-30', 4, 1),
(5, '2024-05-31', 5, 2),
(6, '2024-06-30', 1, 3),
(7, '2024-07-31', 2, 3),
(8, '2024-08-31', 3, 2),
(9, '2024-09-30', 4, 1),
(10, '2024-10-31', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `S_DATE_TIME` date DEFAULT NULL,
  `S_DURATION` int(11) DEFAULT NULL,
  `M_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`S_DATE_TIME`, `S_DURATION`, `M_ID`) VALUES
('2024-01-05', 60, 1),
('2024-02-05', 45, 2),
('2024-03-05', 30, 3),
('2024-04-05', 90, 4),
('2024-05-05', 60, 5),
('2024-06-05', 45, 6),
('2024-07-05', 30, 7),
('2024-08-05', 60, 8),
('2024-09-05', 75, 9),
('2024-10-05', 90, 10);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `T_ID` int(11) NOT NULL,
  `T_NAME` varchar(50) DEFAULT NULL,
  `T_DEADLINE` date DEFAULT NULL,
  `STATUS` varchar(50) DEFAULT NULL,
  `U_ID` int(11) DEFAULT NULL,
  `P_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`T_ID`, `T_NAME`, `T_DEADLINE`, `STATUS`, `U_ID`, `P_ID`) VALUES
(1, 'Task 1', '2024-01-15', 'Pending', 1, 1),
(2, 'Task 2', '2024-02-15', 'Completed', 2, 2),
(3, 'Task 3', '2024-03-15', 'In Progress', 3, 3),
(4, 'Task 4', '2024-04-15', 'Pending', 4, 4),
(5, 'Task 5', '2024-05-15', 'Pending', 5, 5),
(6, 'Task 6', '2024-06-15', 'Completed', 6, 1),
(7, 'Task 7', '2024-07-15', 'Pending', 7, 2),
(8, 'Task 8', '2024-08-15', 'In Progress', 8, 3),
(9, 'Task 9', '2024-09-15', 'Completed', 9, 4),
(10, 'Task 10', '2024-10-15', 'Pending', 10, 5);

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `TEAM_ID` int(11) NOT NULL,
  `TEAM_NAME` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`TEAM_ID`, `TEAM_NAME`) VALUES
(1, 'Code Breaker'),
(2, 'Trio'),
(3, 'Team Zed');

-- --------------------------------------------------------

--
-- Table structure for table `track_time`
--

CREATE TABLE `track_time` (
  `TRACK_ID` int(11) NOT NULL,
  `DATE_TIME` date DEFAULT NULL,
  `U_ID` int(11) DEFAULT NULL,
  `T_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `track_time`
--

INSERT INTO `track_time` (`TRACK_ID`, `DATE_TIME`, `U_ID`, `T_ID`) VALUES
(1, '2024-01-05', 1, 1),
(2, '2024-02-05', 2, 2),
(3, '2024-03-05', 3, 3),
(4, '2024-04-05', 4, 4),
(5, '2024-05-05', 5, 5),
(6, '2024-06-05', 6, 6),
(7, '2024-07-05', 7, 7),
(8, '2024-08-05', 8, 8),
(9, '2024-09-05', 9, 9),
(10, '2024-10-05', 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `U_ID` int(11) NOT NULL,
  `U_NAME` varchar(50) DEFAULT NULL,
  `U_MAIL` varchar(50) DEFAULT NULL,
  `TEAM_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`U_ID`, `U_NAME`, `U_MAIL`, `TEAM_ID`) VALUES
(1, 'Taposhi', 'taposhi@gmail.com', 1),
(2, 'Partho', 'partho@gmail.com', 2),
(3, 'Shohana', 'shohana@gmail.com', 2),
(4, 'Shahtaz', 'shahtaz@gmail.com', 3),
(5, 'Tusar', 'tusar@gmail.com', 2),
(6, 'Esha', 'esha@gmail.com', 1),
(7, 'Tasnim', 'tasnim@gmail.com', 1),
(8, 'Afia', 'afia@gmail.com', 2),
(9, 'Tuba', 'tuba@gmail.com', 3),
(10, 'Shimanto', 'shimanto@gmail.com', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`C_ID`),
  ADD UNIQUE KEY `C_MAIL` (`C_MAIL`);

--
-- Indexes for table `meeting`
--
ALTER TABLE `meeting`
  ADD PRIMARY KEY (`M_ID`),
  ADD KEY `T_ID` (`T_ID`),
  ADD KEY `TEAM_ID` (`TEAM_ID`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`P_ID`),
  ADD KEY `TEAM_ID` (`TEAM_ID`),
  ADD KEY `C_ID` (`C_ID`);

--
-- Indexes for table `reminder`
--
ALTER TABLE `reminder`
  ADD PRIMARY KEY (`R_ID`),
  ADD KEY `M_ID` (`M_ID`),
  ADD KEY `T_ID` (`T_ID`),
  ADD KEY `U_ID` (`U_ID`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`REPORT_ID`),
  ADD KEY `P_ID` (`P_ID`),
  ADD KEY `TEAM_ID` (`TEAM_ID`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD KEY `M_ID` (`M_ID`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`T_ID`),
  ADD KEY `U_ID` (`U_ID`),
  ADD KEY `P_ID` (`P_ID`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`TEAM_ID`);

--
-- Indexes for table `track_time`
--
ALTER TABLE `track_time`
  ADD PRIMARY KEY (`TRACK_ID`),
  ADD KEY `U_ID` (`U_ID`),
  ADD KEY `T_ID` (`T_ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`U_ID`),
  ADD KEY `TEAM_ID` (`TEAM_ID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `meeting`
--
ALTER TABLE `meeting`
  ADD CONSTRAINT `meeting_ibfk_1` FOREIGN KEY (`T_ID`) REFERENCES `tasks` (`T_ID`),
  ADD CONSTRAINT `meeting_ibfk_2` FOREIGN KEY (`TEAM_ID`) REFERENCES `team` (`TEAM_ID`);

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`TEAM_ID`) REFERENCES `team` (`TEAM_ID`),
  ADD CONSTRAINT `projects_ibfk_2` FOREIGN KEY (`C_ID`) REFERENCES `client` (`C_ID`);

--
-- Constraints for table `reminder`
--
ALTER TABLE `reminder`
  ADD CONSTRAINT `reminder_ibfk_1` FOREIGN KEY (`M_ID`) REFERENCES `meeting` (`M_ID`),
  ADD CONSTRAINT `reminder_ibfk_2` FOREIGN KEY (`T_ID`) REFERENCES `tasks` (`T_ID`),
  ADD CONSTRAINT `reminder_ibfk_3` FOREIGN KEY (`U_ID`) REFERENCES `users` (`U_ID`);

--
-- Constraints for table `report`
--
ALTER TABLE `report`
  ADD CONSTRAINT `report_ibfk_1` FOREIGN KEY (`P_ID`) REFERENCES `projects` (`P_ID`),
  ADD CONSTRAINT `report_ibfk_2` FOREIGN KEY (`TEAM_ID`) REFERENCES `team` (`TEAM_ID`);

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`M_ID`) REFERENCES `meeting` (`M_ID`);

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`U_ID`) REFERENCES `users` (`U_ID`),
  ADD CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`P_ID`) REFERENCES `projects` (`P_ID`);

--
-- Constraints for table `track_time`
--
ALTER TABLE `track_time`
  ADD CONSTRAINT `track_time_ibfk_1` FOREIGN KEY (`U_ID`) REFERENCES `users` (`U_ID`),
  ADD CONSTRAINT `track_time_ibfk_2` FOREIGN KEY (`T_ID`) REFERENCES `tasks` (`T_ID`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`TEAM_ID`) REFERENCES `team` (`TEAM_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
